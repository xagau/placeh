Sample configuration files for:
```
SystemD: placehd.service
Upstart: placehd.conf
OpenRC:  placehd.openrc
         placehd.openrcconf
CentOS:  placehd.init
OS X:    org.placeh.placehd.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
